<?php
define("host","localhost");
define("user","vivek1");
define("pass","22010");
define("dbname","muzilla");
?>